let videos = [];

function upload() {
  const input = document.getElementById("uploadVideo");
  const username = document.getElementById("username").value || "Anonymous";

  if (input.files.length === 0) {
    alert("Please upload a video!");
    return;
  }

  const file = URL.createObjectURL(input.files[0]);
  videos.push({ uri: file, user: username, likes: 0 });

  displayVideos();
}

function displayVideos() {
  const videoList = document.getElementById("videoList");
  videoList.innerHTML = "";

  videos.forEach((video, index) => {
    const div = document.createElement("div");
    div.innerHTML = `
      <h3>@${video.user}</h3>
      <video src="${video.uri}" controls loop></video>
      <p>❤️ ${video.likes}</p>
      <button onclick="like(${index})">Like</button>
    `;
    videoList.appendChild(div);
  });
}

function like(index) {
  videos[index].likes++;
  displayVideos();
}
// Show Go Live button only if eligible
{followers[username] >= 1000 && (
  <TouchableOpacity onPress={startLiveStream} style={styles.button}>
    <Text style={styles.text}>🔴 Go Live</Text>
  </TouchableOpacity>
)}
